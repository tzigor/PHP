<?php
    $title = "My first title";

include "site_1.php";